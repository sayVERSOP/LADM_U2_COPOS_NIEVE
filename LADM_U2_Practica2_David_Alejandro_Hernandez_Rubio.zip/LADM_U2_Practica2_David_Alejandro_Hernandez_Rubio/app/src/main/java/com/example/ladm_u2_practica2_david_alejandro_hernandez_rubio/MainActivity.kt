package com.example.ladm_u2_practica2_david_alejandro_hernandez_rubio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    var pLienzo: Lienzo ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(Lienzo (this) )
        pLienzo=Lienzo(this)
        setContentView(pLienzo!!)

        Animate(this).start()
    }
}
