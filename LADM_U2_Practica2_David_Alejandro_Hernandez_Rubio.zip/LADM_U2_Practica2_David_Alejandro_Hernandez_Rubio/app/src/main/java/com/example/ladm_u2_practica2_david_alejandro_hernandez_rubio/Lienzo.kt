package com.example.ladm_u2_practica2_david_alejandro_hernandez_rubio

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class Lienzo (p: MainActivity) : View(p) {

    var puntero = p
    var copo1 = Copo(30,30,10)
    var copo2 = Copo(238,740,10)
    var copo3 = Copo(150,710,10)
    var copo4 = Copo(65,720,10)
    var copo5 = Copo(167,140,10)
    var copo6 = Copo(100,50,10)
    var copo7 = Copo(300,40,10)
    var copo8 = Copo(398,110,10)
    var copo9 = Copo(200,78,10)
    var copo10 = Copo(90,110,10)

    var copo11 = Copo(303,130,10)
    var copo12 = Copo(128,375,10)
    var copo13 = Copo(130,200,10)
    var copo14 = Copo(225,360,10)
    var copo15 = Copo(587,700,10)
    var copo16 = Copo(580,420,10)
    var copo17 = Copo(120,449,10)
    var copo18 = Copo(268,700,10)
    var copo19 = Copo(500,173,10)
    var copo20 = Copo(471,234,10)

    var copo21 = Copo(50,150,10)
    var copo22 = Copo(45,275,10)
    var copo23 = Copo(50,350,10)
    var copo24 = Copo(510,230,10)
    var copo25 = Copo(400,340,10)
    var copo26 = Copo(480,780,10)
    var copo27 = Copo(220,369,10)
    var copo28 = Copo(264,467,10)
    var copo29 = Copo(290,183,10)
    var copo30 = Copo(371,208,10)

    var copo31 = Copo(630,30,10)
    var copo32 = Copo(738,175,10)
    var copo33 = Copo(850,90,10)
    var copo34 = Copo(795,12,10)
    var copo35 = Copo(1127,770,10)
    var copo36 = Copo(780,50,10)
    var copo37 = Copo(670,40,10)
    var copo38 = Copo(698,110,10)
    var copo39 = Copo(750,78,10)
    var copo40 = Copo(860,110,10)

    var copo41 = Copo(1020,500,10)
    var copo42 = Copo(1080,375,10)
    var copo43 = Copo(1080,200,10)
    var copo44 = Copo(980,750,10)
    var copo45 = Copo(970,240,10)
    var copo46 = Copo(920,420,10)
    var copo47 = Copo(820,449,10)
    var copo48 = Copo(840,367,10)
    var copo49 = Copo(780,173,10)
    var copo50 = Copo(980,234,10)

    var copo51 = Copo(1200,770,10)
    var copo52 = Copo(1220,275,10)
    var copo53 = Copo(1190,700,10)
    var copo54 = Copo(1180,230,10)
    var copo55 = Copo(1270,670,10)
    var copo56 = Copo(1230,350,10)
    var copo57 = Copo(1158,369,10)
    var copo58 = Copo(1140,467,10)
    var copo59 = Copo(1190,183,10)
    var copo60 = Copo(1290,208,10)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        var paint = Paint()


        //Nuvesonas

        paint.color = Color.GRAY
        c.drawRect(0f, 0f, 1438f, 2122f, paint)
        paint.color = Color.WHITE
        c.drawRect(0f,1200f,1438f,2122f,paint)
        paint.color = Color.BLACK
        c.drawRect(700f, 800f, 600f, 1100f, paint)

        //casa
        paint.color = Color.BLUE
        c.drawRect(700f, 900f, 430f, 1200f, paint)
        paint.color = Color.WHITE
        c.drawCircle(480f, 1000f, 30f, paint)
        paint.color = Color.WHITE
        c.drawCircle(640f, 1000f, 30f, paint)
        paint.color = Color.BLACK
        c.drawRect(650f,1050f,500f,1200f,paint)
        paint.color = Color.GREEN

        //Nuvesonas
        paint.color = Color.WHITE
        c.drawCircle(110f,120f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(150f,80f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(200f,120f,70f,paint)
        paint.color = Color.WHITE

        //Nuvesonas
        paint.color = Color.WHITE
        c.drawCircle(710f,120f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(750f,80f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(800f,120f,70f,paint)
        paint.color = Color.WHITE

        //Nuvesonas
        paint.color = Color.WHITE
        c.drawCircle(1210f,120f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(1250f,80f,70f,paint)
        paint.color = Color.WHITE
        c.drawCircle(1300f,120f,70f,paint)
        paint.color = Color.WHITE

        //arbol Hojas
        paint.color = Color.GREEN
        c.drawCircle(140f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(100f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(120f, 940f, 30f, paint)
        //Troncoso
        paint.color = Color.rgb(58,41,41)
        c.drawRect(90f,1000f,150f,1200f,paint)
        //Arbol Hojas
        paint.color = Color.GREEN
        c.drawCircle(360f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(320f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(340f, 940f, 30f, paint)
        //Troncoso
        paint.color = Color.rgb(58,41,41)
        c.drawRect(310f,1000f,370f,1200f,paint)
        //DERECHA
        //arbol Hojas
        paint.color = Color.GREEN
        c.drawCircle(860f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(820f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(840f, 940f, 30f, paint)
        //Troncoso
        paint.color = Color.rgb(58,41,41)
        c.drawRect(810f,1000f,870f,1200f,paint)
        //Arbol Hojas
        paint.color = Color.GREEN
        c.drawCircle(1060f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(1020f, 980f, 30f, paint)
        paint.color = Color.GREEN
        c.drawCircle(1040f, 940f, 30f, paint)
        //Troncoso
        paint.color = Color.rgb(58,41,41)
        c.drawRect(1010f,1000f,1070f,1200f,paint)

//dibujando copos
        paint.color= Color.WHITE
        copo1.pintar(c,paint)
        paint.color= Color.WHITE
        copo2.pintar(c,paint)
        paint.color= Color.WHITE
        copo3.pintar(c,paint)
        paint.color= Color.WHITE
        copo4.pintar(c,paint)
        paint.color= Color.WHITE
        copo5.pintar(c,paint)
        paint.color= Color.WHITE
        copo6.pintar(c,paint)
        paint.color= Color.WHITE
        copo7.pintar(c,paint)
        paint.color= Color.WHITE
        copo8.pintar(c,paint)
        paint.color= Color.WHITE
        copo9.pintar(c,paint)
        paint.color= Color.WHITE
        copo10.pintar(c,paint)
        paint.color= Color.WHITE
        copo11.pintar(c,paint)
        paint.color= Color.WHITE
        copo12.pintar(c,paint)
        paint.color= Color.WHITE
        copo13.pintar(c,paint)
        paint.color= Color.WHITE
        copo14.pintar(c,paint)
        paint.color= Color.WHITE
        copo15.pintar(c,paint)
        paint.color= Color.WHITE
        copo16.pintar(c,paint)
        paint.color= Color.WHITE
        copo17.pintar(c,paint)
        paint.color= Color.WHITE
        copo18.pintar(c,paint)
        paint.color= Color.WHITE
        copo19.pintar(c,paint)
        paint.color= Color.WHITE
        copo20.pintar(c,paint)

        paint.color= Color.WHITE
        copo21.pintar(c,paint)
        paint.color= Color.WHITE
        copo22.pintar(c,paint)
        paint.color= Color.WHITE
        copo23.pintar(c,paint)
        paint.color= Color.WHITE
        copo24.pintar(c,paint)
        paint.color= Color.WHITE
        copo25.pintar(c,paint)
        paint.color= Color.WHITE
        copo26.pintar(c,paint)
        paint.color= Color.WHITE
        copo27.pintar(c,paint)
        paint.color= Color.WHITE
        copo28.pintar(c,paint)
        paint.color= Color.WHITE
        copo29.pintar(c,paint)
        paint.color= Color.WHITE
        copo30.pintar(c,paint)

        paint.color = Color.WHITE
        copo31.pintar(c,paint)
        paint.color = Color.WHITE
        copo32.pintar(c,paint)
        paint.color = Color.WHITE
        copo33.pintar(c,paint)
        paint.color = Color.WHITE
        copo34.pintar(c,paint)
        paint.color = Color.WHITE
        copo35.pintar(c,paint)
        paint.color= Color.WHITE
        copo36.pintar(c,paint)
        paint.color= Color.WHITE
        copo37.pintar(c,paint)
        paint.color= Color.WHITE
        copo38.pintar(c,paint)
        paint.color= Color.WHITE
        copo39.pintar(c,paint)
        paint.color= Color.WHITE
        copo40.pintar(c,paint)

        paint.color= Color.WHITE
        copo41.pintar(c,paint)
        paint.color= Color.WHITE
        copo42.pintar(c,paint)
        paint.color= Color.WHITE
        copo43.pintar(c,paint)
        paint.color= Color.WHITE
        copo44.pintar(c,paint)
        paint.color= Color.WHITE
        copo45.pintar(c,paint)
        paint.color= Color.WHITE
        copo46.pintar(c,paint)
        paint.color= Color.WHITE
        copo47.pintar(c,paint)
        paint.color= Color.WHITE
        copo48.pintar(c,paint)
        paint.color= Color.WHITE
        copo49.pintar(c,paint)
        paint.color= Color.WHITE
        copo50.pintar(c,paint)

        paint.color= Color.WHITE
        copo51.pintar(c,paint)
        paint.color= Color.WHITE
        copo52.pintar(c,paint)
        paint.color= Color.WHITE
        copo53.pintar(c,paint)
        paint.color= Color.WHITE
        copo54.pintar(c,paint)
        paint.color= Color.WHITE
        copo55.pintar(c,paint)
        paint.color= Color.WHITE
        copo56.pintar(c,paint)
        paint.color= Color.WHITE
        copo57.pintar(c,paint)
        paint.color= Color.WHITE
        copo58.pintar(c,paint)
        paint.color= Color.WHITE
        copo59.pintar(c,paint)
        paint.color= Color.WHITE
        copo60.pintar(c,paint)



    }//onDraw

    fun AnimoCopo () {
        copo1.caida(width, height)
        copo2.caida(width,height)
        copo3.caida(width,height)
        copo4.caida(width,height)
        copo5.caida(width,height)
        copo6.caida(width, height)
        copo7.caida(width,height)
        copo8.caida(width,height)
        copo9.caida(width,height)
        copo10.caida(width,height)
        copo11.caida(width, height)
        copo12.caida(width,height)
        copo13.caida(width,height)
        copo14.caida(width,height)
        copo15.caida(width,height)
        copo16.caida(width, height)
        copo17.caida(width,height)
        copo18.caida(width,height)
        copo19.caida(width,height)
        copo20.caida(width,height)
        copo21.caida(width, height)
        copo22.caida(width,height)
        copo23.caida(width,height)
        copo24.caida(width,height)
        copo25.caida(width,height)
        copo26.caida(width, height)
        copo27.caida(width,height)
        copo28.caida(width,height)
        copo29.caida(width,height)
        copo30.caida(width,height)
        copo31.caida(width, height)
        copo32.caida(width,height)
        copo33.caida(width,height)
        copo34.caida(width,height)
        copo35.caida(width,height)
        copo36.caida(width, height)
        copo37.caida(width,height)
        copo38.caida(width,height)
        copo39.caida(width,height)
        copo40.caida(width,height)
        copo41.caida(width, height)
        copo42.caida(width,height)
        copo43.caida(width,height)
        copo44.caida(width,height)
        copo45.caida(width,height)
        copo46.caida(width, height)
        copo47.caida(width,height)
        copo48.caida(width,height)
        copo49.caida(width,height)
        copo50.caida(width,height)
        copo51.caida(width, height)
        copo52.caida(width,height)
        copo53.caida(width,height)
        copo54.caida(width,height)
        copo55.caida(width,height)
        copo56.caida(width, height)
        copo57.caida(width,height)
        copo58.caida(width,height)
        copo59.caida(width,height)
        copo60.caida(width,height)


        invalidate()
    }

}//fin class

        /* paint.color = Color.MAGENTA
         c.drawRect(700f, 900f, 430f, 1200f, paint)
         .rgb(58,41,41)
         */



