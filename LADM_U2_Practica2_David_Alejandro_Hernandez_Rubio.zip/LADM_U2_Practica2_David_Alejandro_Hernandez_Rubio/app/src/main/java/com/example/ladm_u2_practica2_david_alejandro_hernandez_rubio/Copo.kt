package com.example.ladm_u2_practica2_david_alejandro_hernandez_rubio

import android.graphics.Canvas
import android.graphics.Paint

class Copo (){
    var x = 0f
    var y = 0f
    var radio = 0f
    var ancho = 0f
    var alto = 0f
    var incY = 5

    constructor(x:Int, y:Int, radio:Int) : this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.radio = radio.toFloat()
    }//constructor

    fun pintar(c: Canvas, p: Paint){
        c.drawCircle(x,y,radio,p)
    }//pintar

    fun caida(ancho:Int, alto:Int){
        y+= incY
        if(y>=1010){
            y=(y-y)+1
        }
    }//caida

}//class
