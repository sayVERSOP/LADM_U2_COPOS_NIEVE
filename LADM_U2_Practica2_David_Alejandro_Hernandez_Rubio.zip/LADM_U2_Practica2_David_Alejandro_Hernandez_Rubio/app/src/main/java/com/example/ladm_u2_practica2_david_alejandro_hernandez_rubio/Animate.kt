package com.example.ladm_u2_practica2_david_alejandro_hernandez_rubio

class Animate (p: MainActivity) :Thread() {
    var puntero = p

    override fun run() {
        super.run()

        while (true) {
            sleep(200)
            puntero.runOnUiThread {
                puntero.pLienzo!!.AnimoCopo()
            }
        }
    }

}